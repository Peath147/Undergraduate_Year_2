<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Contact</title>
</head>
<body>
	<h1>Contact</h1>
	<img src="../img/contact.png">
	<img src="/learnphp/02_html/img/contact.png">
	<a href="../index.php">ย้อนกลับไปหน้าแรก</a>
	<a href="/learnphp/02_html/index.php">ย้อนกลับไปหน้าแรก</a>
</body>
</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ตัวแปรชนิดเลขจำนวนเต็ม เลขฐานสิบ</title>
</head>

<body>

    <?php
    echo "<h2>ตัวแปรชนิดเลขจำนวนเต็ม เลขฐานสิบ </h2>";
    $a = 100;
    $b = -100;
    $c = +100;
    echo "\$a = " . $a . "<br>";
    echo "\$b = " . $b . "<br>";
    echo "\$c = " . $c . "<br>";
    ?>

</body>

</html>

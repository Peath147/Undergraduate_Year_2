<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ตัวแปรชนิดเลขจำนวนเต็ม เลขฐานแปด</title>
</head>

<body>

    <?php
    echo "<h2>ตัวแปรชนิดเลขจำนวนเต็ม เลขฐานแปด </h2>";
    $a = 0100; //มีค่ําเป็น 64 ฐํานสิบ //
    $b = -0100; //มีค่ําเป็น -64 ฐํานสิบ //
    $c = +0100; //มีค่ําเป็น 64 ฐํานสิบ //
    echo "\$a = " . $a . "<br>";
    echo "\$b = " . $b . "<br>";
    echo "\$c = " . $c . "<br>";
    ?>

</body>

</html>

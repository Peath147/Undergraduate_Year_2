<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>การใช้ Array แบบระบุตำแหน่งแบบตัวเลข</title>
</head>

<body>

    <?php
    echo "<h2> การใช้ Array แบบระบุตำแหน่งแบบตัวเลข </h2> ";
    $cars[0] = "TOYOTA";
    $cars[1] = "HONDA";
    $cars[2] = "NISSON";
    $cars[3] = "MISUBISHI";
    echo $cars[0] . " และ " . $cars[1] . " เป็นรถญี่ปุ่น";
    ?>

</body>

</html>

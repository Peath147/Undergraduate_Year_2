<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>การใช้อาร์เรย์หนึ่งมิติ</title>
</head>

<body>

    <?php
    echo "<h2> การใช้อาร์เรย์หนึ่งมิติ </h2> ";
    $Friut = array("ส้ม", "เงําะ", "ขนุน", "มังคุด", "ทุเรียน");
    echo '$Friut[0] = ' . $Friut[0] . '<br>';
    echo '$Friut[1] = ' . $Friut[1] . '<br>';
    echo '$Friut[2] = ' . $Friut[2] . '<br>';
    echo '$Friut[3] = ' . $Friut[3] . '<br>';
    ?>

</body>

</html>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ตัวแปรชนิดข้อความกับการใช้เครื่องหมายคำพูด</title>
</head>

<body>

    <?php
    echo "<h2>ตัวแปรชนิดข้อความกับการใช้เครื่องหมายคำพูด </h2>";
    $firstname = "สมชาย";
    $lastname = "รักชาติ";
    //ส่วนกํารแสดงผล //
    echo "สวัสดี $firstname $lastname \n" . "<br>";
    echo 'สวัสดี $firstname $lastname \n';
    ?>

</body>

</html>

{

    "metadata" :
    {
        "formatVersion" : 3.1,
        "sourceFile"    : "WaltHead.obj",
        "generatedBy"   : "OBJConverter",
        "vertices"      : 8146,
        "faces"         : 16160,
        "normals"       : 8146,
        "uvs"           : 0,
        "materials"     : 1
    },

    "materials": [	{
	"DbgColor" : 15658734,
	"DbgIndex" : 0,
	"DbgName" : "lambert2SG.001",
	"colorAmbient" : [0.0, 0.0, 0.0],
	"colorDiffuse" : [0.64, 0.64, 0.64],
	"colorSpecular" : [0.25, 0.25, 0.25],
	"illumination" : 2,
	"opticalDensity" : 1.0,
	"specularCoef" : 92.156863,
	"transparency" : 1.0
	}],

    "buffers": "WaltHead_bin.bin"

}
